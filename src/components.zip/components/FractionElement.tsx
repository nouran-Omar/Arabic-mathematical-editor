// src/components/FractionElement.tsx

import React from 'react';
import type { RenderElementProps } from 'slate-react';
import { Element as SlateElement } from 'slate';

export const FractionElement = ({ attributes, children, element }: RenderElementProps) => {
  // 1. تحويل الأطفال لمصفوفة لسهولة التعامل
  const childrenArray = React.Children.toArray(children);
  
  // 2. البحث عن البسط والمقام داخل البيانات
  // الافتراضي: الأول بسط والثاني مقام
  let numComp = childrenArray[0];
  let denComp = childrenArray[1];

  // التحقق الذكي: لو البيانات موجودة، نتأكد مين البسط ومين المقام
  if (SlateElement.isElement(element)) {
    const nIndex = element.children.findIndex((c: any) => c.type === 'numerator');
    const dIndex = element.children.findIndex((c: any) => c.type === 'denominator');
    
    // لو وجدناهم، نأخذ المكونات الصحيحة بغض النظر عن ترتيبهم في المصفوفة
    if (nIndex !== -1) numComp = childrenArray[nIndex];
    if (dIndex !== -1) denComp = childrenArray[dIndex];
  }

  return (
   <span 
      {...attributes} 
      className="inline-flex flex-col items-center mx-1 align-middle"
      style={{ verticalAlign: 'middle' }} 
    >
        {/* === المنطقة العلوية (دائماً للبسط) === */}
        <span className="w-full 
           border-b-2 border-slate-900 
           pt-1 pb-1 
           flex justify-center items-end 
           text-center min-w-[24px]">
           {/* هنا نضع مكون البسط الذي وجدناه */}
           {numComp}
        </span>
        
        {/* === المنطقة السفلية (دائماً للمقام) === */}
        <span className="w-full 
           pt-1 pb-1
           flex justify-center items-start 
           text-center min-w-[24px]">
           {/* هنا نضع مكون المقام الذي وجدناه */}
           {denComp}
        </span>
    </span>
  );
};