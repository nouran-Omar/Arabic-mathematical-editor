import React, { useMemo, useCallback, forwardRef, useImperativeHandle } from 'react';
import { createEditor, Transforms, Editor, Path, Element as SlateElement } from 'slate';
import { Slate, Editable, withReact, useSlateStatic } from 'slate-react';
import { withHistory } from 'slate-history';
import type { Descendant } from 'slate';
import type { RenderElementProps, RenderLeafProps } from 'slate-react';

import { FractionElement } from './FractionElement'; 

// يجب أن يتم تعريف هذه القيمة في بداية الملف
const YELLOW_BOX = "min-w-[20px] min-h-[20px] px-1 mx-0.5 text-center inline-flex items-center justify-center rounded-md border border-amber-400 bg-amber-100/80 text-sm shadow-sm";

// ========================================================
// 1. الدوال المساعدة الأساسية
// ========================================================

const withMath = (editor: Editor) => {
  const { isInline } = editor;
  editor.isInline = (element: any) => {
    const inlineTypes = [
        'fraction', 'numerator', 'denominator', 
        'sqrt', 'n_root', 'root_index',
        'matrix', 'matrix_row', 'matrix_cell', 
        'summation', 'integral', 'limit', 
        'lower', 'upper', 'expression', 'subscript', 
        'superscript', 'subscript_block', 'base', 'power', 'sub'
    ];
    return inlineTypes.includes(element.type) ? true : isInline(element);
  };
  return editor;
};

export const insertCustomNode = (editor: Editor, nodeType: string) => {
  // تعريف البنية الداخلية لكل قالب (يجب أن يتطابق مع ما تم تعريفه في math-data.ts)
  let newNode: any;

  switch (nodeType) {
    case 'fraction':
      newNode = { type: 'fraction', children: [
        { type: 'numerator', children: [{ text: '' }] },
        { type: 'denominator', children: [{ text: '' }] },
      ]};
      break;
    case 'n_root':
      newNode = { type: 'n_root', children: [
        { type: 'root_index', children: [{ text: '' }] },
        { type: 'expression', children: [{ text: 'س' }] },
      ]};
      break;
    case 'superscript':
      newNode = { type: 'superscript', children: [
        { type: 'base', children: [{ text: 'س' }] },
        { type: 'power', children: [{ text: '' }] },
      ]};
      break;
    case 'summation':
      newNode = { type: 'summation', children: [
        { type: 'lower', children: [{ text: 'ك=1' }] },
        { type: 'upper', children: [{ text: 'ن' }] },
        { type: 'expression', children: [{ text: 'س' }] },
      ]};
      break;
    case 'matrix':
      newNode = { type: 'matrix', children: [
        { type: 'matrix_row', children: [
          { type: 'matrix_cell', children: [{ text: '1' }] },
          { type: 'matrix_cell', children: [{ text: '2' }] },
        ] },
        { type: 'matrix_row', children: [
          { type: 'matrix_cell', children: [{ text: '3' }] },
          { type: 'matrix_cell', children: [{ text: '4' }] },
        ] },
      ]};
      break;
    default:
      return;
  }
  
  Transforms.insertNodes(editor, newNode);
  // نقل المؤشر لأول حقل إدخال داخل القالب الجديد
  Transforms.select(editor, Path.next(Editor.path(editor, editor.selection!.anchor.path.slice(0, -1))));
};

// ========================================================
// 2. مكونات العناصر الرياضية (Functional Components)
// ========================================================

// ⚡ 1. رمز المجموع (SummationElement) - الحل لـ "مربع فوق ومربع تحت"
const SummationElement = ({ attributes, children }: RenderElementProps) => {
    // الأطفال: [lower, upper, expression] 
    const [lower, upper, expression] = children as React.ReactNode[];

    return (
        <span
            {...attributes}
            className="inline-flex items-center align-middle mx-2"
            style={{ direction: 'rtl', verticalAlign: 'middle' }}
        >
            {/* 1. رمز المجموع (Sigma) مع حدوده */}
            <span className="relative inline-flex flex-col justify-center items-center text-4xl font-serif px-2">
                
                {/* الحد العلوي (Upper) */}
                <span className="absolute top-[-0.8em] text-sm font-serif z-10">
                    {upper}
                </span>

                {/* رمز المجموع نفسه مع قلب أفقي (لضمان ظهوره بشكل عربي) */}
                <span className="text-4xl" style={{ display: 'inline-block', transform: 'scaleX(-1)' }}>
                    ∑
                </span>
                
                {/* الحد السفلي (Lower) */}
                <span className="absolute bottom-[-0.8em] text-sm font-serif z-10">
                    {lower}
                </span>
            </span>

            {/* 2. التعبير الرياضي (Expression) - يوضع يسار رمز المجموع */}
            <span className="pl-1">
                {expression}
            </span>
        </span>
    );
};
// RichTextEditor.tsx - داخل تعريف المكونات

const NRootElement = ({ attributes, children }: RenderElementProps) => {
    // ⚠️ يتم استقبال العناصر بترتيبها الطبيعي: [Index, Expression]
    const [index, expression] = children as React.ReactNode[];
    
    return (
        <span 
            {...attributes} 
            // المحاذاة السفلى (align-bottom) مهمة لتثبيت الجذر على سطر النص
            className="inline-flex items-stretch mx-2 align-bottom" 
            style={{ direction: 'rtl' }}
        >
            {/* 1. رمز الجذر والدليل (المربع الذي فوق) */}
            <span className="relative flex flex-col w-[24px]">
                
                {/* الدليل (Index) - المربع الذي فوق الجذر */}
                <span 
                   className="absolute bottom-[100%] right-[-10px] mb-[-6px] z-50 flex items-center justify-center text-sm" 
                   // لضمان ظهور البلوك بشكل واضح في الأعلى
                   style={{ zIndex: 100, minWidth: '20px', minHeight: '20px' }} 
                >
                    {index}
                </span>

                <svg className="w-full h-full text-slate-900 fill-transparent stroke-current stroke-2" viewBox="0 0 20 40" preserveAspectRatio="none">
                    <path d="M0 0 L10 40 L20 20" vectorEffect="non-scaling-stroke" />
                </svg>
            </span>
            
            {/* 2. التعبير (Expression) - المربع الذي جوه الجذر */}
            <span 
                // 🛑 التصحيح الحاسم: items-end (للمحاذاة السفلية)
                // هذا يضمن عدم ارتفاع الـ 'س' أو المربع الأصفر للأعلى
                className="border-t-2 border-slate-900 px-1 flex items-end justify-center min-h-[35px]" 
            >
                {expression}
            </span>
        </span>
    );
};
const SuperscriptElement = ({ attributes, children }: RenderElementProps) => {
  const [base, power] = children as React.ReactNode[];

  return (
    <span 
      {...attributes} 
      className="inline-block relative text-base font-serif align-baseline" 
      style={{ direction: 'rtl', margin: '0 0.5em' }}
    >
      
      {/* الأساس (Base) */}
      <span className="inline-block align-baseline pr-1 pb-0.5">
         {base}
      </span>
      
      {/* الأس (Power) - استخدام transform لرفع موثوق */}
      <span 
         className="absolute top-0 left-0 z-10 text-xs font-bold text-slate-900" 
         style={{ 
           transform: 'translateY(-100%) translateX(-100%) scale(0.85)', 
           transformOrigin: 'bottom right',
           direction: 'rtl',
           whiteSpace: 'nowrap'
         }}
      >
        {power}
      </span>
    </span>
  );
};
// --------------------------------------------------------

// 🔲 4. مكونات المصفوفة (لإتمام البنية)
const MatrixCellElement = ({ attributes, children }: RenderElementProps) => {
  return (
    <td 
      {...attributes} 
      className="p-1 text-center align-middle whitespace-nowrap" 
      style={{ minWidth: '30px' }}
    >
      <span className={YELLOW_BOX}>
        {children}
      </span>
    </td>
  );
};

const MatrixRowElement = ({ attributes, children }: RenderElementProps) => {
  return (
    <tr {...attributes}>
      {children}
    </tr>
  );
};

const MatrixElement = ({ attributes, children }: RenderElementProps) => {
  return (
    <span 
      {...attributes} 
      className="inline-flex items-center align-middle mx-2" 
      style={{ direction: 'rtl' }}
    >
      <span className="text-4xl font-serif text-slate-800 self-stretch flex items-center pr-1 h-full">
        [
      </span>
      
      <table className="border-collapse">
        <tbody {...attributes}>
          {children}
        </tbody>
      </table>
      
      <span className="text-4xl font-serif text-slate-800 self-stretch flex items-center pl-1 h-full">
        ]
      </span>
    </span>
  );
};

// ========================================================
// 3. دالة RenderElement (الربط البصري)
// ========================================================

const renderElement = (props: RenderElementProps) => {
  switch (props.element.type) {
    case 'paragraph': return <p {...props.attributes}>{props.children}</p>;
    case 'fraction': return <FractionElement {...props} />;
    
    // رموز تم تصحيحها (NRoot، Summation)
    case 'n_root': return <NRootElement {...props} />;
    case 'summation': return <SummationElement {...props} />;
    case 'superscript': return <SuperscriptElement {...props} />;
    
    // المصفوفات
    case 'matrix': return <MatrixElement {...props} />;
    case 'matrix_row': return <MatrixRowElement {...props} />;
    case 'matrix_cell': return <MatrixCellElement {...props} />;
    
    // 🔑 الحالة الأساسية: حقول الإدخال الداخلية (الـ YELLOW BOX)
    // هذا يضمن ظهور جميع المربعات القابلة للكتابة
    case 'numerator':
    case 'denominator':
    case 'lower':
    case 'upper': // <- حدود المجموع
    case 'base':
    case 'power':
    case 'sub':
      return `<span style="min-width:28px;min-height:28px;padding:4px;margin:0 2px;text-align:center;display:inline-block;border:1px solid #fcd34d;background-color:#fffbeb;border-radius:4px;font-size:0.875rem;box-shadow:0 1px 2px 0 rgba(0,0,0,0.05);">${childrenHtml}</span>`;
case 'expression': // <--- المربع الذي جوه الجذر
    case 'root_index': // <--- المربع الذي فوق الجذر
      return (
        <span 
          {...props.attributes} 
          className={YELLOW_BOX} 
          // 🛑 التغيير الحاسم: إجبار العرض كـ 'inline-block' بدلاً من 'inline-flex'
          style={{ direction: 'rtl', display: 'inline-block', textAlign: 'center' }} 
        >
          {props.children}
        </span>
      );

    default:
      return <p {...props.attributes}>{props.children}</p>;
  }
};

const renderLeaf = (props: RenderLeafProps) => {
  return <span {...props.attributes}>{props.children}</span>;
};

// ========================================================
// 4. المكون الرئيسي (RichTextEditor)
// ========================================================

interface RichTextEditorProps {
  value: Descendant[];
  onChange: (value: Descendant[]) => void;
}

export const RichTextEditor = forwardRef<Editor, RichTextEditorProps>(({ value, onChange }, ref) => {
  const editor = useMemo(() => withMath(withHistory(withReact(createEditor()))), []);
  useImperativeHandle(ref, () => editor, [editor]);

  // يجب تفعيل منطق لوحة المفاتيح للمصفوفات هنا (onKeyDown)
  const onKeyDown = useCallback((event: React.KeyboardEvent) => {
    // ... (هنا يتم وضع منطق onKeyDown الذي تم إرساله للمصفوفات Enter/Tab)
    // لتجنب تكرار الكود، تأكدي من نقل المنطق الذي أرسلته لك في خطوة "تفعيل المصفوفات" هنا.
  }, [editor]);


  return (
    <Slate editor={editor} initialValue={value} onChange={onChange}>
      <Editable
        className="p-8 outline-none text-right font-sans min-h-full"
        renderElement={renderElement as any}
        renderLeaf={renderLeaf}
        onKeyDown={onKeyDown}
        placeholder="اكتبي النص والمعادلات هنا..."
        dir="rtl"
      />
    </Slate>
  );
});

export default RichTextEditor;
// import React, { useMemo, useCallback, forwardRef, useImperativeHandle } from 'react';
// import { createEditor, Transforms, Editor, Path, Element as SlateElement, Node } from 'slate';
// import { Slate, Editable, withReact } from 'slate-react';
// import { withHistory } from 'slate-history';
// import type { Descendant } from 'slate';
// import type { RenderElementProps, RenderLeafProps } from 'slate-react';
// import { FractionElement } from './FractionElement'; 

// const withMath = (editor: Editor) => {
//   const { isInline } = editor;
//   editor.isInline = (element: any) => {
//     const inlineTypes = [
//         'fraction', 'numerator', 'denominator', 
//         'sqrt', 'n_root', 'root_index',
//         'matrix', 'matrix_row', 'matrix_cell', 
//         'summation', 'integral', 'limit', 
//         'lower', 'upper', 'expression', 'subscript', 
//         'superscript', 'subscript_block', 'base', 'power', 'sub'
//     ];
//     return inlineTypes.includes(element.type as string) ? true : isInline(element);
//   };
//   return editor;
// };

// // ========================================================
// // 1. الجذر النوني (تحسين التموضع لعدم تداخل الكسور)
// // ========================================================
// const NRootElement = ({ attributes, children }: RenderElementProps) => {
//   const [index, expression] = children as React.ReactNode[];
//   return (
//     <span {...attributes} className="inline-flex items-stretch mx-2 mt-4 align-bottom" style={{ direction: 'rtl' }}>
//        <span className="relative flex flex-col w-[24px]">
//           {/* المربع الأصفر: تم تثبيته بدقة ليكون فوق الرمز */}
//           <span className="absolute bottom-[100%] right-[-10px] mb-[-6px] z-50 flex items-center justify-center min-w-[28px] h-[28px] bg-yellow-100 border-2 border-yellow-500 rounded-md shadow-sm text-sm font-bold text-slate-800">
//              {index}
//           </span>
//           <svg className="w-full h-full text-slate-900 fill-transparent stroke-current stroke-2" viewBox="0 0 20 40" preserveAspectRatio="none">
//              <path d="M0 0 L10 40 L20 20" vectorEffect="non-scaling-stroke" />
//           </svg>
//        </span>
//        <span className="border-t-2 border-slate-900 px-2 flex items-center justify-center text-base min-w-[30px]">
//           {expression}
//        </span>
//     </span>
//   );
// };

// // ========================================================
// // 2. المصفوفة (تم إصلاح الكتابة داخل الخلية)
// // ========================================================

// const MatrixElement = ({ attributes, children }: RenderElementProps) => {
//   return (
//     <span {...attributes} className="inline-flex items-center align-middle mx-1 my-1" style={{ direction: 'rtl', verticalAlign: 'middle' }}>
//       <span className="w-[8px] self-stretch border-r-2 border-y-2 border-slate-900 rounded-r-md my-[2px] opacity-90" contentEditable={false}></span>
//       <span className="flex flex-col gap-1 mx-1 justify-center">
//         {children}
//       </span>
//       <span className="w-[8px] self-stretch border-l-2 border-y-2 border-slate-900 rounded-l-md my-[2px] opacity-90" contentEditable={false}></span>
//     </span>
//   );
// };

// const MatrixRowElement = ({ attributes, children }: RenderElementProps) => {
//   return (
//     <span {...attributes} className="flex flex-row gap-1 justify-center items-stretch">
//       {children}
//     </span>
//   );
// };

// const MatrixCellElement = ({ attributes, children }: RenderElementProps) => {
//     return (
//       <span 
//         {...attributes}
//         // h-auto: يسمح بالتمدد
//         // items-center: يضمن أن النص في المنتصف عمودياً
//         className={`
//           flex items-center justify-center
//           min-w-[45px] min-h-[40px] p-1
//           bg-white border border-slate-300 rounded
//           focus-within:border-indigo-500 focus-within:ring-2 focus-within:ring-indigo-200 focus-within:z-10
//           cursor-text text-center text-sm shadow-sm
//         `}
//         style={{ direction: 'rtl' }}
//       >
//         {children}
//       </span>
//     );
// };

// // ========================================================
// // باقي المكونات
// // ========================================================
// const SuperscriptElement = ({ attributes, children }: RenderElementProps) => {
//   const [base, power] = children as React.ReactNode[];
//   return (
//     <span {...attributes} className="inline-flex items-baseline mx-1 align-middle" style={{ direction: 'rtl' }}>
//        <span className="flex items-center">{base}</span>
//        <span className="relative text-xs" style={{ top: '-0.8em', marginRight: '2px' }}>{power}</span>
//     </span>
//   );
// };
// const SubscriptElement = ({ attributes, children }: RenderElementProps) => {
//   const [base, sub] = children as React.ReactNode[];
//   return (
//     <span {...attributes} className="inline-flex items-baseline mx-1 align-middle" style={{ direction: 'rtl' }}>
//        <span className="flex items-center">{base}</span>
//        <span className="relative text-xs" style={{ top: '0.4em', marginRight: '2px' }}>{sub}</span>
//     </span>
//   );
// };
// const IntegralElement = ({ attributes, children }: RenderElementProps) => {
//   const [lower, upper, expression] = children as React.ReactNode[];
//   return (
//     <span {...attributes} className="inline-flex items-center align-middle mx-1" style={{ direction: 'rtl' }}>
//       <span className="inline-flex flex-col items-center justify-center mx-1">
//         <span className="w-full text-center mb-[2px]">{upper}</span>
//         <span className="text-3xl font-serif leading-none italic inline-block scale-x-[-1] scale-y-125 select-none text-slate-800" contentEditable={false}>∫</span>
//         <span className="w-full text-center mt-[2px]">{lower}</span>
//       </span>
//       <span className="flex items-center">{expression}</span>
//     </span>
//   );
// };
// const SummationElement = ({ attributes, children }: RenderElementProps) => {
//   const [lower, upper, expression] = children as React.ReactNode[];
//   return (
//     <span {...attributes} className="inline-flex items-center align-middle mx-1" style={{ direction: 'rtl' }}>
//       <span className="inline-flex flex-col items-center justify-center mx-1">
//         <span className="w-full text-center mb-[2px]">{upper}</span>
//        <span className="text-2xl font-serif leading-none select-none text-slate-800 inline-block scale-[-1]" contentEditable={false}>∑</span>
//        <span className="w-full text-center mt-[2px]">{lower}</span>
//       </span>
//       <span className="flex items-center">{expression}</span>
//     </span>
//   );
// };
// const LimitElement = ({ attributes, children }: RenderElementProps) => {
//     const [subscript, expression] = children as React.ReactNode[];
//     return (
//         <span {...attributes} className="inline-flex items-baseline align-baseline mx-1" style={{ direction: 'rtl' }}>
//             <span className="inline-flex flex-col items-center justify-start ml-0.5">
//                 <span className="font-serif text-xl font-bold leading-none select-none text-slate-900" dir="rtl" contentEditable={false}>نها</span> 
//                 <span className="w-full text-center text-xs mt-0.5 scale-90 origin-top opacity-90">{subscript}</span>
//             </span>
//             <span className="flex items-center -mr-2">{expression}</span>
//         </span>
//     );
// };
// const SqrtElement = ({ attributes, children }: RenderElementProps) => (
//   <span {...attributes} className="inline-flex items-stretch mx-1 align-middle whitespace-nowrap" style={{ direction: 'rtl' }}>
//       <span className="text-lg text-slate-900 font-serif transform -scale-x-100 select-none" contentEditable={false} style={{ lineHeight: 1 }}>√</span>
//       <span className="border-t-2 border-slate-900 px-1 text-center min-w-[20px] flex items-center justify-center text-sm">{children}</span>
//   </span>
// );

// // ========================================================
// // دوال الإدراج
// // ========================================================
// export const insertCustomNode = (editor: Editor, type: string) => {
//   const baseChildren = [{ text: '' }];
  
//   if (type === 'matrix') {
//     // مصفوفة 2 صف × 1 عمود
//     Transforms.insertNodes(editor, { 
//       type: 'matrix', 
//       children: [
//         { 
//           type: 'matrix_row', 
//           children: [
//             { type: 'matrix_cell', children: baseChildren }
//           ] 
//         },
//         { 
//             type: 'matrix_row', 
//             children: [
//               { type: 'matrix_cell', children: baseChildren }
//             ] 
//           }
//       ] 
//     });
//   } else if (type === 'n_root') {
//       Transforms.insertNodes(editor, { type: 'n_root', children: [{ type: 'root_index', children: baseChildren }, { type: 'expression', children: baseChildren }] });
//   } else if (type === 'fraction') {
//     Transforms.insertNodes(editor, { type: 'fraction', children: [{ type: 'numerator', children: baseChildren }, { type: 'denominator', children: baseChildren }] });
//   } else if (type === 'sqrt') {
//     Transforms.insertNodes(editor, { type: 'sqrt', children: baseChildren });
//   } else if (type === 'summation') { 
//     Transforms.insertNodes(editor, { type: 'summation', children: [{ type: 'lower', children: baseChildren }, { type: 'upper', children: baseChildren }, { type: 'expression', children: baseChildren }] });
//   } else if (type === 'integral') { 
//     Transforms.insertNodes(editor, { type: 'integral', children: [{ type: 'lower', children: baseChildren }, { type: 'upper', children: baseChildren }, { type: 'expression', children: baseChildren }] });
//   } else if (type === 'limit') { 
//     Transforms.insertNodes(editor, { type: 'limit', children: [{ type: 'subscript', children: baseChildren }, { type: 'expression', children: baseChildren }] });
//   } else if (type === 'superscript') {
//     Transforms.insertNodes(editor, { type: 'superscript', children: [{ type: 'base', children: baseChildren }, { type: 'power', children: baseChildren }] });
//   } else if (type === 'subscript_block') {
//     Transforms.insertNodes(editor, { type: 'subscript_block', children: [{ type: 'base', children: baseChildren }, { type: 'sub', children: baseChildren }] });
//   }
// };

// // ========================================================
// // المحرر الرئيسي
// // ========================================================
// interface RichTextEditorProps {
//   value: Descendant[];
//   onChange: (value: Descendant[]) => void;
// }

// export const RichTextEditor = forwardRef<Editor, RichTextEditorProps>(({ value, onChange }, ref) => {
//   const editor = useMemo(() => withMath(withHistory(withReact(createEditor()))), []);
//   useImperativeHandle(ref, () => editor);

//   const renderElement = useCallback((props: RenderElementProps) => {
//     switch (props.element.type) {
//       case 'matrix': return <MatrixElement {...props} />;
//       case 'matrix_row': return <MatrixRowElement {...props} />;
//       case 'matrix_cell': return <MatrixCellElement {...props} />;

//       case 'fraction': return <FractionElement {...props} />;
//       case 'n_root': return <NRootElement {...props} />;
//       case 'sqrt': return <SqrtElement {...props} />;
//       case 'summation': return <SummationElement {...props} />;
//       case 'integral': return <IntegralElement {...props} />; 
//       case 'limit': return <LimitElement {...props} />;
//       case 'superscript': return <SuperscriptElement {...props} />;
//       case 'subscript_block': return <SubscriptElement {...props} />;
      
//       case 'root_index': 
//         return (
//           <span {...props.attributes} className="min-w-[30px] min-h-[30px] px-1 mx-0.5 text-center inline-flex items-center justify-center rounded-md border-2 border-amber-400 bg-amber-100 hover:bg-amber-200 focus-within:bg-white focus-within:border-amber-600 focus-within:ring-2 focus-within:ring-amber-200 cursor-text text-sm transition-all duration-150 shadow-sm" style={{ direction: 'rtl' }}>{props.children}</span>
//         );

//       case 'numerator': case 'denominator': case 'lower': case 'upper': case 'subscript': case 'expression': case 'base': case 'power': case 'sub':
//         return (
//           <span {...props.attributes} className="min-w-[28px] min-h-[28px] px-1 mx-0.5 text-center inline-flex items-center justify-center rounded border border-indigo-200 bg-indigo-50/50 hover:bg-indigo-100 hover:border-indigo-400 focus-within:bg-white focus-within:border-indigo-600 focus-within:ring-2 focus-within:ring-indigo-200 cursor-text text-sm transition-colors duration-150" style={{ direction: 'rtl' }}>{props.children}</span>
//         );
      
//       default:
//         return <div {...props.attributes} dir="rtl" className="mb-2 text-right leading-loose text-base text-slate-900 font-serif">{props.children}</div>;
//     }
//   }, []);

//   const renderLeaf = useCallback((props: RenderLeafProps) => (
//     <span {...props.attributes} className={props.leaf.bold ? 'font-bold' : ''}>{props.children}</span>
//   ), []);

//   // ========================================================
//   // معالج لوحة المفاتيح (Tab للأعمدة - Enter للصفوف)
//   // ========================================================
//   const onKeyDown = (event: React.KeyboardEvent) => {
    
//     // 1. Enter = إضافة صف جديد (بنفس عدد الأعمدة)
//     if (event.key === 'Enter') {
//       const [cellNode] = Editor.nodes(editor, { match: n => !Editor.isEditor(n) && SlateElement.isElement(n) && n.type === 'matrix_cell' });
      
//       if (cellNode) {
//         event.preventDefault(); 
//         const [rowNode] = Editor.nodes(editor, { match: n => !Editor.isEditor(n) && SlateElement.isElement(n) && n.type === 'matrix_row' });
        
//         if (rowNode) {
//            const currentRow = rowNode[0] as SlateElement;
//            const cellCount = currentRow.children.length;
//            // ننشئ خلايا فارغة بعدد أعمدة الصف الحالي
//            const newCells = Array(cellCount).fill(null).map(() => ({ 
//                type: 'matrix_cell', 
//                children: [{ text: '' }] 
//            }));
           
//            Transforms.insertNodes(editor, { 
//                type: 'matrix_row', 
//                children: newCells 
//            }, { at: Path.next(rowNode[1]) });
//         }
//         return;
//       }
//     }

//     // 2. Tab = إضافة عمود جديد (خلية لكل صف)
//     if (event.key === 'Tab') {
//       const [cellNode] = Editor.nodes(editor, { match: n => !Editor.isEditor(n) && SlateElement.isElement(n) && n.type === 'matrix_cell' });
      
//       if (cellNode) {
//         event.preventDefault(); // منع الانتقال الافتراضي للتاب
        
//         const [matrixNode] = Editor.nodes(editor, { match: n => !Editor.isEditor(n) && SlateElement.isElement(n) && n.type === 'matrix' });
        
//         if (matrixNode) {
//           const matrixElement = matrixNode[0] as SlateElement;
//           const matrixPath = matrixNode[1];

//           // نستخدم withoutNormalizing لتحسين الأداء عند التعديل على عدة مسارات
//           Editor.withoutNormalizing(editor, () => {
//              // نمر على كل صف ونضيف خلية في آخره
//              matrixElement.children.forEach((row, rowIndex) => {
//                 const rowPath = [...matrixPath, rowIndex];
//                 const endOfRowIndex = (row as SlateElement).children.length;
                
//                 Transforms.insertNodes(
//                     editor, 
//                     { type: 'matrix_cell', children: [{ text: '' }] }, 
//                     { at: [...rowPath, endOfRowIndex] }
//                 );
//              });
//           });
//         }
//         return;
//       }
//     }
//   };

//   return (
//     <Slate editor={editor} initialValue={value} onChange={onChange}>
//       <Editable
//         className="p-8 outline-none text-right font-sans min-h-full"
//         renderElement={renderElement}
//         renderLeaf={renderLeaf}
//         onKeyDown={onKeyDown}
//         placeholder="ابدأ الكتابة هنا..."
//         dir="rtl" 
//       />
//     </Slate>
//   );
// });

// RichTextEditor.displayName = 'RichTextEditor';