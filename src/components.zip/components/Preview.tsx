// src/components/Preview.tsx

// import React, { useEffect, useRef } from 'react';

// interface PreviewProps {
//   content: string;
// }

// declare global {
//   interface Window { MathJax: any; }
// }

// export const Preview: React.FC<PreviewProps> = ({ content }) => {
//   const previewRef = useRef<HTMLDivElement>(null);

//   useEffect(() => {
//     if (previewRef.current) {
//       // نترك المحتوى كما هو لأنه HTML جاهز
//       const processedContent = content;

//       // التعديل هنا: أزلنا leading-loose واستخدمنا styles مباشرة لضمان عدم وجود مسافات دخيلة
//       const htmlContent = processedContent
//         .split('\n')
//         .map(line => line.trim() ? `<div style="margin-bottom: 0.5rem; min-height: 1.5em; direction: rtl; line-height: normal;">${line}</div>` : '') 
//         .join('');

//       previewRef.current.innerHTML = htmlContent;

//       if (window.MathJax) {
//         window.MathJax.typesetPromise([previewRef.current]).catch(console.error);
//       }
//     }
//   }, [content]);

//   return (
//     <div 
//       ref={previewRef} 
//       // أزلنا leading-loose من هنا أيضاً
//       className="w-full text-xl break-words p-6 bg-white rounded-lg min-h-[200px] shadow-inner border border-slate-100 font-serif" 
//       dir="rtl"
//       style={{ fontFamily: "'Amiri', 'Traditional Arabic', serif" }}
//     >
//       {/* المعاينة */}
//     </div>
//   );
// };




// ======================ده ال شغاله بيه  ======================================
// // src/components/Preview.tsx

import React, { useEffect, useRef } from 'react';

interface PreviewProps {
  content: string;
}

declare global {
  interface Window { MathJax: any; }
}

export const Preview: React.FC<PreviewProps> = ({ content }) => {
  const previewRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (previewRef.current && window.MathJax) {
      
      // 1. معالجة الرموز لتطبيق نفس الـ Scale الموجود في المحرر
      let processedContent = content;

      // تطبيق ستايل السيجما (Scale -1: قلب كامل)
      // نستبدل \sum بـ \style{transform: scale(-1)}{\sum}
      processedContent = processedContent.replace(
        /\\sum/g, 
        '\\style{display:inline-block; transform: scale(-1)}{\\sum}'
      );

      // تطبيق ستايل التكامل (Scale X -1, Scale Y 1.25: قلب أفقي ومط طولي)
      // نستبدل \int بـ \style{transform: scaleX(-1) scaleY(1.25)}{\int}
      processedContent = processedContent.replace(
        /\\int/g, 
        '\\style{display:inline-block; transform: scaleX(-1) }{\\int}'
      );

      // 2. تحويل النص القادم (اللي فيه \n) لـ HTML divs
      const htmlContent = processedContent
        .split('\n')
        .map(line => line.trim() ? `<div class="mb-2 min-h-[1.5em] text-slate-900 leading-loose" style="direction: rtl;">${line}</div>` : '') 
        .join('');

      // 3. نحط المحتوى كـ HTML
      previewRef.current.innerHTML = htmlContent;

      // 4. MathJax يعيد الرسم
      window.MathJax.typesetPromise([previewRef.current]).catch(console.error);
    }
  }, [content]);

  return (
    <div 
      ref={previewRef} 
      className="w-full text-xl break-words p-6 bg-white rounded-lg min-h-[200px] shadow-inner border border-slate-100 font-serif" 
      dir="rtl"
      style={{ fontFamily: "'Amiri', 'Traditional Arabic', serif" }}
    >
      {/* المعاينة */}
    </div>
  );
};